package Interfaces;
import CLASSES.*;
public interface IticeketOperation{
	void ticketInsert(String ticketNo);
	void ticketRemove(String ticketNo);
}