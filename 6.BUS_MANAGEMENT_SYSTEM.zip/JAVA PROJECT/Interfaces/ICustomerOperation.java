package Interfaces;
import CLASSES.*;
public interface ICustomerOperation{
	void getCustomer(String name);
	void insertCustomer(String name);
	void removeCustomer(String name);
	
	
}