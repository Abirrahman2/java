package Interfaces;
import CLASSES.*;
public interface IEmployeeOperation{
	void getEmployee(String empId);
	void insertEmployee(String empId);
	void removeEmployee(String empId);
}